import pymysql
import boto3
import json

def lambda_handler(event, context):
    rds = boto3.client('rds')
    rds_obj = rds.describe_db_instances(DBInstanceIdentifier="ecp-rds")

    endpoint = rds_obj['DBInstances'][0]["Endpoint"]["Address"] # get using boto3
    username = "admin" 
    password = "password" 
    database_name = "ecp_dev" 
    try: 
        connection = pymysql.connect(host=endpoint, user=username, password=password, db=database_name)
        cursor = connection.cursor()
        id_str = event.get("id")

        query = "DELETE FROM products WHERE ID=%s" 
        cursor.execute(query, (id_str))
        connection.commit()
        result = "Deleted Successfully"
        cursor.close()
        connection.close()
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"{e}")
        }
    return {
        'statusCode': 200,
        'body': json.dumps(f"{result}")
    }
