import pymysql
import json
import boto3

def handler(event, context):
     
    rds = boto3.client('rds')
    rds_obj = rds.describe_db_instances(DBInstanceIdentifier="ecp-rds")
    
    endpoint = rds_obj['DBInstances'][0]["Endpoint"]["Address"] # get using boto3
    username = "admin" 
    password = "password" 
    database_name = "ecp_dev" 
    
    try:
        connection = pymysql.connect(host=endpoint, user=username, password=password, db=database_name)
        cursor = connection.cursor()
        if (cursor): 
            query = f"INSERT INTO Products (prod_name, prod_price, description) VALUES ({event.prod_name}, {event.prod_price}, {event.description})" 
            cursor.execute(query)
            connection.commit()
            result = "Commit"
        else: 
            result = "Failed"
        cursor.close()
        connection.close()
    except Exception as e: 
        return {
            'statusCode': 500,
            'body': json.dumps(f"Result: {result}, Error: {str(e)}")
        }
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }